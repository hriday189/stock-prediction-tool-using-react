"use client"

import { useState } from "react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ChartContainer } from "@/components/ui/chart"

// Simulated function to fetch historical stock data
const fetchStockData = (symbol: string) => {
  // This is a mock function. In a real app, you'd fetch data from an API
  const basePrice = Math.random() * 100 + 50
  return Array.from({ length: 30 }, (_, i) => ({
    date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    price: basePrice + Math.random() * 10 - 5
  }))
}

// Simple prediction function
const predictNextPrice = (data: { date: string; price: number }[]) => {
  const prices = data.map(d => d.price)
  const avg = prices.reduce((a, b) => a + b, 0) / prices.length
  const lastPrice = prices[prices.length - 1]
  return (avg + lastPrice) / 2
}

export default function Component() {
  const [symbol, setSymbol] = useState("")
  const [stockData, setStockData] = useState<{ date: string; price: number }[]>([])
  const [prediction, setPrediction] = useState<number | null>(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const data = fetchStockData(symbol)
    setStockData(data)
    setPrediction(predictNextPrice(data))
  }

  return (
    <Card className="w-full max-w-3xl">
      <CardHeader>
        <CardTitle>Stock Prediction App</CardTitle>
        <CardDescription>Enter a stock symbol to get a prediction</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="flex space-x-2 mb-4">
          <Input
            type="text"
            value={symbol}
            onChange={(e) => setSymbol(e.target.value.toUpperCase())}
            placeholder="Enter stock symbol (e.g., AAPL)"
            className="flex-grow"
          />
          <Button type="submit">Predict</Button>
        </form>

        {prediction !== null && (
          <div className="mb-4">
            <h3 className="text-lg font-semibold">Prediction for {symbol}</h3>
            <p>Next predicted price: ${prediction.toFixed(2)}</p>
          </div>
        )}

        {stockData.length > 0 && (
          <ChartContainer className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={stockData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-background border border-border p-2 rounded shadow">
                        <p className="text-sm font-medium">{`Date: ${payload[0].payload.date}`}</p>
                        <p className="text-sm">{`Price: $${payload[0].value.toFixed(2)}`}</p>
                      </div>
                    );
                  }
                  return null;
                }} />
                <Legend />
                <Line type="monotone" dataKey="price" stroke="hsl(var(--primary))" name="Stock Price" />
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
        )}
      </CardContent>
    </Card>
  )
}